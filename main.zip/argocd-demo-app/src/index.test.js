const request = require('supertest');
const server = require('./index');

afterAll(() => {
  server.close();
});

describe('GET /', () => {
  it('returns Hello World', async () => {
    const res = await request(server).get('/');
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toBe('Hello World v2');
  });
});

describe('GET /health', () => {
  it('returns ok', async () => {
    const res = await request(server).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
